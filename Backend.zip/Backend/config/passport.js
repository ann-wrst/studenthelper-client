import {Strategy as LocalStrategy} from "passport-local";

import bcrypt from "bcrypt";

export function checkAuthenticated() {
    return function (req, res, next) {
        if (req.isAuthenticated()) {
            return next()
        }
        res.status(403).send({message: 'Access denied, please log in!'});
    }
}

function initialize(passport, getUserByEmail, getUserById) {
    const authenticateUser = async (email, password, done) => {
        const user = getUserByEmail(email);
        if (user == null) {
            return done(null, false, {message: 'No user with that email'});
        }
        try {
            if (await bcrypt.compare(password, user.password)) {
                return done(null, user);
            } else {
                return done(null, false, {message: 'Password incorrect'});
            }
        } catch (e) {
            return done(e);
        }
    }

    passport.use(new LocalStrategy({usernameField: 'email'}, authenticateUser))
    passport.serializeUser((user, done) => done(null, user.id))
    passport.deserializeUser((id, done) => {
        const user = getUserById(id);
        if (user) {
            return done(null, user);
        } else {
            return done(null, false, {message: 'No user with that email'});
        }
    })
    passport.checkAuthenticated = checkAuthenticated;
}

export default initialize;
/*import passport from "passport";
import {Strategy as LocalStrategy} from "passport-local";
import bcrypt from "bcrypt";

export function authenticationMiddleware() {
    return function (req, res, next) {
        if (req.isAuthenticated()) {
            return next()
        }
        res.status(403).send({message: 'Access denied, please log in!'});
    }
}
passport.serializeUser((user, done) => {
    done(null, user.email);
});

passport.deserializeUser((email, done) => {
    findByEmail({where: {email}}).then((user) => {
        done(null, user);
        return null;
    });
});

export default function initPassport() {

    passport.use(new LocalStrategy({
            usernameField: 'email',
            passwordField: 'password',
            session: false
        }, (email, password, done) => {
            findByEmail(email, (err, user) => {
                if (err) {
                    return done(err)
                }
                if (!user) {
                    console.log('User not found')
                    return done(null, false)
                }
                bcrypt.compare(password, user.password, (err, isValid) => {
                    if (err) {
                        return done(err)
                    }
                    if (!isValid) {
                        return done(null, false)
                    }
                    return done(null, user)
                })
            })
        }
    ));

    passport.authenticationMiddleware = authenticationMiddleware
}
*/