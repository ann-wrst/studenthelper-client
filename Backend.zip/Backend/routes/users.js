import {Router} from "express";
import {update, findAll, findOne} from "../Controllers/UserController.js";
import passport from "passport";

const router = Router();

export default app => {
    router.get("/", findAll);
    router.get('/:idUser', findOne);
    router.put("/:idUser", update);

    app.use('/api/users',passport.checkAuthenticated(), router);//,
}