import express from 'express';
import bodyparser from 'body-parser';
import passport from 'passport'; //TODO: PASSPORT

import session from 'express-session';
import cors from 'cors';

import {sequelize} from './config/dbConnect.js';
import config from './config/config.js';
import logger from "./logger.js";


//routes
import routes_index from './routes/index.js';
import routes_users from './routes/users.js';
import routes_authorization from './routes/authorization.js';


import initializePassport from "./config/passport.js";

const {json, urlencoded} = bodyparser;
const usersCookie = [];

;(async () => {
    const app = express();
    initializePassport(
        passport,
        email => usersCookie.find(user => user.email === email),
        id => usersCookie.find(user => user.id === id)
    )
    app.use(json());
    app.use(urlencoded({extended: true}));

    app.use(
        session({
            ...config.session
        })
    );
    app.use(passport.initialize({}));
    app.use(passport.session({}));
    app.use(cors({
        origin: "*"
    }));


    logger(app);

    routes_index(app);
    routes_users(app);
    routes_authorization(app);

    try {
        if (await sequelize.sync()) {
            app.listen(config.app.port, () => {
                console.log(`Server is listen on ${config.app.port} \n`);
            });
        }
    } catch (err) {
        console.log(err);
    }
})();
